"""
文件读取相关的数据模型
File reading related schemas
"""

from typing import Optional, List, Dict, Any, Literal
from pydantic import BaseModel, Field


class FileReadingRequest(BaseModel):
    """文件读取请求模型"""

    # 必需参数
    task_id: str = Field(..., description="任务ID，从任务JSON中获取文件路径")
    target_format: str = Field(
        default="plain_text",
        description="目标输出格式: plain_text, markdown, dataframe"
    )
    table_precision: Optional[int] = Field(
        default=10,
        ge=0,
        le=20,
        description="读取表格的精度（仅对Excel等表格文件有效）"
    )

    # OCR相关配置
    enable_ocr: bool = Field(default=True, description="是否启用OCR文本识别")
    ocr_mode: Optional[str] = Field(
        default="prompt_ocr",
        description="OCR模式: prompt_ocr, prompt_layout_all_en, prompt_layout_only_en, prompt_grounding_ocr"
    )

    # 自定义参数
    custom_parameters: Optional[Dict[str, Any]] = Field(
        default_factory=dict,
        description="自定义参数，可以接收任何额外的参数"
    )


class FileReadingResponse(BaseModel):
    """文件读取响应模型"""

    success: bool = Field(..., description="是否读取成功")
    task_id: str = Field(..., description="任务ID")
    file_path: str = Field(..., description="文件路径")
    target_format: str = Field(..., description="目标输出格式")
    content: Optional[str] = Field(None, description="读取到的文本内容")
    dataframe: Optional[List[Dict[str, Any]]] = Field(None, description="读取到的数据表格（当target_format为dataframe时）")
    metadata: Optional[Dict[str, Any]] = Field(None, description="文件元数据信息")
    processing_time: Optional[float] = Field(None, description="处理耗时（秒）")
    error_message: Optional[str] = Field(None, description="错误信息（如果读取失败）")
    error_details: Optional[Dict[str, Any]] = Field(None, description="详细错误信息")
