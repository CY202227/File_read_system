from __future__ import annotations

# content_reading 模式下允许的输出格式（对齐 schema 与 job_manager）
CONTENT_READING_OUTPUT_FORMATS = {"markdown", "plain_text", "dataframe"}


