"""
分块处理相关的数据模型
Chunking related schemas
"""

from typing import Optional, List, Dict, Any, Literal
from pydantic import BaseModel, Field


class ChunkingRequest(BaseModel):
    """分块请求模型"""

    # 必需参数
    content: str = Field(..., description="待分块的文本内容")
    strategy: str = Field(
        default="auto",
        description="分块策略: auto, character_splitting, recursive_character_splitting, document_specific_splitting, semantic_splitting, agentic_splitting, alternative_representation_chunking, custom_delimiter_splitting"
    )

    # 可选参数
    task_id: Optional[str] = Field(None, description="任务ID，用于跟踪处理进度")
    chunk_size: Optional[int] = Field(
        default=1000,
        ge=100,
        le=99999999,
        description="分块大小（字符数）"
    )
    chunk_overlap: Optional[int] = Field(
        default=200,
        ge=0,
        le=1000,
        description="分块重叠大小（字符数）"
    )

    # 策略特定配置
    recursive_config: Optional[Dict[str, Any]] = Field(
        default=None,
        description="递归字符分块配置"
    )
    semantic_config: Optional[Dict[str, Any]] = Field(
        default=None,
        description="语义分块配置"
    )
    document_config: Optional[Dict[str, Any]] = Field(
        default=None,
        description="文档特定分块配置"
    )
    agentic_config: Optional[Dict[str, Any]] = Field(
        default=None,
        description="智能代理分块配置"
    )
    alternative_config: Optional[Dict[str, Any]] = Field(
        default=None,
        description="替代表示分块配置"
    )

    # 自定义参数
    custom_parameters: Optional[Dict[str, Any]] = Field(
        default_factory=dict,
        description="自定义参数，可以接收任何额外的参数"
    )


class ChunkData(BaseModel):
    """分块数据模型"""

    chunk_id: str = Field(..., description="分块ID")
    content: str = Field(..., description="分块内容")
    start_position: int = Field(..., description="在原文本中的起始位置")
    end_position: int = Field(..., description="在原文本中的结束位置")
    metadata: Optional[Dict[str, Any]] = Field(None, description="分块元数据")


class ChunkingResponse(BaseModel):
    """分块响应模型"""

    success: bool = Field(..., description="是否分块成功")
    strategy: str = Field(..., description="使用的分块策略")
    total_chunks: int = Field(..., description="总分块数量")
    chunks: List[ChunkData] = Field(..., description="分块结果列表")
    original_length: int = Field(..., description="原文本长度")
    processing_time: Optional[float] = Field(None, description="处理耗时（秒）")
    metadata: Optional[Dict[str, Any]] = Field(None, description="处理元数据")
    error_message: Optional[str] = Field(None, description="错误信息（如果分块失败）")
    error_details: Optional[Dict[str, Any]] = Field(None, description="详细错误信息")
