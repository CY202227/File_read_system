"""
测试新创建的独立接口
Test the newly created independent APIs
"""

import requests
import json
from pathlib import Path

def test_file_info_api():
    """测试文件信息接口"""
    print("=== 测试文件信息接口 ===")

    # 创建一个测试文件
    test_file = Path("test_sample.txt")
    test_file.write_text("这是一个测试文件的内容", encoding="utf-8")

    try:
        # 测试文件信息接口
        response = requests.get("http://localhost:8000/api/v1/file/info/test_sample.txt")
        print(f"文件信息接口响应: {response.status_code}")
        if response.status_code == 200:
            data = response.json()
            print(f"文件大小: {data.get('file_size')} bytes")
            print(f"文件类型: {data.get('file_extension')}")
    except Exception as e:
        print(f"文件信息接口测试失败: {e}")
    finally:
        # 清理测试文件
        if test_file.exists():
            test_file.unlink()

def test_supported_formats_api():
    """测试支持格式接口"""
    print("\n=== 测试支持格式接口 ===")

    try:
        response = requests.get("http://localhost:8000/api/v1/file/convert/supported")
        print(f"支持格式接口响应: {response.status_code}")
        if response.status_code == 200:
            data = response.json()
            print("支持的预转换格式:")
            for fmt, targets in data.get("pre_conversion", {}).get("formats", {}).items():
                print(f"  {fmt} -> {targets}")
    except Exception as e:
        print(f"支持格式接口测试失败: {e}")

def test_workflow_status_api():
    """测试工作流状态接口"""
    print("\n=== 测试工作流状态接口 ===")

    try:
        response = requests.get("http://localhost:8000/api/v1/file/workflow/status")
        print(f"工作流状态接口响应: {response.status_code}")
        if response.status_code == 200:
            data = response.json()
            print(f"可用步骤数量: {len(data.get('available_steps', []))}")
            for step in data.get("available_steps", []):
                print(f"  {step['name']}: {step['endpoint']}")
    except Exception as e:
        print(f"工作流状态接口测试失败: {e}")

def test_api_docs():
    """测试API文档是否包含新接口"""
    print("\n=== 测试API文档 ===")

    try:
        response = requests.get("http://localhost:8000/docs")
        print(f"API文档页面响应: {response.status_code}")
        if response.status_code == 200:
            print("✅ API文档页面正常访问")
        else:
            print("❌ API文档页面访问失败")
    except Exception as e:
        print(f"API文档测试失败: {e}")

if __name__ == "__main__":
    print("开始测试新创建的接口...")

    # 注意：这些测试需要在应用运行时执行
    # 您可以先启动应用：python main.py
    # 然后在另一个终端运行：python test_new_apis.py

    test_api_docs()
    test_supported_formats_api()
    test_workflow_status_api()
    test_file_info_api()

    print("\n测试完成！")
    print("注意：完整的接口测试需要在应用运行时进行。")
    print("启动应用：python main.py")
    print("然后访问：http://localhost:8000/docs 查看所有新接口")
