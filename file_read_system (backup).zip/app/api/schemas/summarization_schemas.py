"""
总结处理相关的数据模型
Summarization related schemas
"""

from typing import Optional, List, Dict, Any, Literal
from pydantic import BaseModel, Field


class SummarizationRequest(BaseModel):
    """总结请求模型"""

    # 必需参数
    content: str = Field(..., description="待总结的文本内容")
    summary_type: str = Field(
        default="general",
        description="总结类型: general, key_points, extractive, abstractive, multi_document"
    )

    # 可选参数
    task_id: Optional[str] = Field(None, description="任务ID，用于跟踪处理进度")
    length: Optional[int] = Field(
        default=500,
        ge=100,
        le=2000,
        description="总结长度（字符数）"
    )
    focus: Optional[List[str]] = Field(
        default=["main_points", "key_findings", "recommendations"],
        description="总结重点关注的方面"
    )
    language: Optional[str] = Field(
        default="zh",
        description="总结语言: zh, en"
    )

    # 模型配置
    model_name: Optional[str] = Field(
        default=None,
        description="使用的模型名称，不填则使用默认模型"
    )
    temperature: Optional[float] = Field(
        default=0.3,
        ge=0.0,
        le=2.0,
        description="生成温度"
    )
    max_tokens: Optional[int] = Field(
        default=1024,
        ge=1,
        description="最大输出token数"
    )

    # 多文档总结特有参数
    documents: Optional[List[str]] = Field(
        default=None,
        description="多文档总结时的文档列表（当summary_type为multi_document时使用）"
    )
    return_top_k: Optional[int] = Field(
        default=None,
        ge=1,
        description="返回前K条要点/段落"
    )

    # 自定义参数
    custom_parameters: Optional[Dict[str, Any]] = Field(
        default_factory=dict,
        description="自定义参数，可以接收任何额外的参数"
    )


class SummarySection(BaseModel):
    """总结段落模型"""

    title: str = Field(..., description="段落标题")
    content: str = Field(..., description="段落内容")
    importance: Optional[int] = Field(None, ge=1, le=10, description="重要性评分（1-10）")


class SummarizationResponse(BaseModel):
    """总结响应模型"""

    success: bool = Field(..., description="是否总结成功")
    summary_type: str = Field(..., description="总结类型")
    summary: str = Field(..., description="总结文本")
    sections: Optional[List[SummarySection]] = Field(None, description="分段总结结果")
    key_points: Optional[List[str]] = Field(None, description="关键要点列表")
    word_count: int = Field(..., description="总结字数")
    original_length: int = Field(..., description="原文长度")
    processing_time: Optional[float] = Field(None, description="处理耗时（秒）")
    metadata: Optional[Dict[str, Any]] = Field(None, description="处理元数据")
    error_message: Optional[str] = Field(None, description="错误信息（如果总结失败）")
    error_details: Optional[Dict[str, Any]] = Field(None, description="详细错误信息")
